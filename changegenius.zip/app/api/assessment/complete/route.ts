import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { calculateScores } from "@/lib/assessment/scoring";
import { TOTAL_QUESTIONS } from "@/lib/assessment/questions";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

const schema = z.object({ assessmentId: z.string().uuid() });

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success)
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const { assessmentId } = parsed.data;

  const cookieStore = await cookies();
  const supabaseAuth = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => cookieStore.getAll(),
        setAll: (s) => s.forEach(({ name, value, options }) => cookieStore.set(name, value, options)),
      },
    }
  )

  const { data: { session } } = await supabaseAuth.auth.getSession()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  )

  // Verify ownership
  const { data: assessment } = await supabase
    .from("assessments")
    .select("id, user_id, status, team_id")
    .eq("id", assessmentId)
    .eq("user_id", session.user.id)
    .single();

  if (!assessment)
    return NextResponse.json(
      { error: "Assessment not found" },
      { status: 404 },
    );
  if (assessment.status === "completed") {
    return NextResponse.json(
      { error: "Assessment already completed" },
      { status: 409 },
    );
  }

  // Fetch all responses
  const { data: responses } = await supabase
    .from("responses")
    .select("question_id, value")
    .eq("assessment_id", assessmentId);

  const uniqueAnswered = new Set(responses?.map((r) => r.question_id)).size;
  if (!responses || uniqueAnswered < TOTAL_QUESTIONS) {
    return NextResponse.json(
      {
        error: `Incomplete — ${uniqueAnswered}/${TOTAL_QUESTIONS} questions answered`,
      },
      { status: 422 },
    );
  }

  // Build response map
  const responseMap: Record<string, number> = {};
  for (const r of responses) responseMap[r.question_id] = r.value;

  // Run scoring engine
  const scores = calculateScores(responseMap);

  // Save scores
  const { error: scoresError } = await supabase.from("scores").upsert(
    {
      assessment_id: assessmentId,
      role_scores: scores.role_scores,
      stage_scores: scores.stage_scores,
      energy_scores: scores.energy_scores,
      derived: scores.derived,
      calculated_at: new Date().toISOString(),
    },
    { onConflict: "assessment_id" },
  );

  if (scoresError) {
    console.error("[assessment/complete] scores error:", scoresError);
    return NextResponse.json(
      { error: "Failed to save scores" },
      { status: 500 },
    );
  }

  // Mark assessment complete
  await supabase
    .from("assessments")
    .update({ status: "completed", completed_at: new Date().toISOString() })
    .eq("id", assessmentId);

  // Update member/profile
  const { derived } = scores;
  const isTeamAssessment = !!assessment.team_id;
  let html = null
  let teamName = ''
  let teamOEmail = ''
  let teamOName =''
  let totalMembers = 0

  console.log("isTeamAssessment",isTeamAssessment)
  
  if (isTeamAssessment) {
      const { data: updatedMember, error: memberError } = await supabase
        .from("team_members")
        .update({
          status: "joined",
          assessment_status: "completed",
          completed_at:      new Date().toISOString(),
          primary_role:      derived.primary_role,
          secondary_role:    derived.secondary_role,
          role_pair_title:   derived.role_pair_title,
          primary_energy:    derived.energy_profile.dominant,
          top_adapts_stages:    derived.top_adapts_stages,
          bottom_adapts_stages: derived.bottom_adapts_stages,
        })
        .eq("team_id", assessment.team_id)
        .eq("user_id", session.user.id)
        .select()

      console.log("[complete] member update result:", { updatedMember, memberError })

      if (memberError) {
        console.error("[assessment/complete] team_members update error:", memberError)
        return NextResponse.json(
          { error: "Failed to update team membership" },
          { status: 500 },
        )
      }

    // Check if this was the last member to complete
    const { data: allMembers } = await supabase
      .from("team_members")
      .select("status, assessment_status")
      .eq("team_id", assessment.team_id)

    const allCompleted = allMembers?.every(m => m.assessment_status === "completed") ?? false

    if (allCompleted) {
      totalMembers = allMembers?.length!
      // Get team + owner details
      const { data: team } = await supabase
        .from("teams")
        .select("name, owner_id")
        .eq("id", assessment.team_id)
        .single()

      if(team){
        teamName = team.name
        const { data: ownerProfile } = await supabase
          .from("profiles")
          .select("email, full_name")
          .eq("id", team.owner_id)
          .single()

        if(ownerProfile){
          teamOEmail = ownerProfile.email
          teamOName = ownerProfile.full_name
        }

        const teamReportRes = await fetch(
          `${process.env.NEXT_PUBLIC_APP_URL}/api/pdf/team?teamId=${assessment.team_id}`,
          { headers: { Cookie: req.headers.get('cookie') ?? '' } }
        )
        
        if (teamReportRes.ok) {
          html = await teamReportRes.text();    
        }
      }

    }
    
  }
  
  const { error: profileError } = await supabase
    .from("profiles")
    .update({
      change_genius_role: derived.primary_role,
      change_genius_role_2: derived.secondary_role,
      role_pair_title: derived.role_pair_title,
      primary_energy: derived.energy_profile.dominant,
      top_adapts_stages: derived.top_adapts_stages,
      bottom_adapts_stages: derived.bottom_adapts_stages,
      onboarded: true,
    })
    .eq("id", session.user.id);

  if (profileError) {
    console.error("[assessment/complete] profile update error:", profileError);
    return NextResponse.json(
      { error: "Failed to update profile" },
      { status: 500 },
    );
  }

  console.log(
    `[assessment/complete] User ${session.user.id} completed assessment. onboarded set to true.`,
  );

  return NextResponse.json({ 
    success: true, 
    assessmentId, 
    derived, 
    team: {
      html,
      teamId: assessment.team_id,
      teamName,
      teamOName,
      teamOEmail,
      totalMembers
    }
  });
}
