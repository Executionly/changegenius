"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import AdminLayout from "../../components/AdminLayout";

interface UserDetail {
  profile: {
    id: string;
    email: string;
    full_name: string | null;
    has_paid: boolean;
    onboarded: boolean;
    change_genius_role: string | null;
    change_genius_role_2: string | null;
    primary_energy: string | null;
    top_adapts_stages: string[];
    bottom_adapts_stages: string[];
    created_at: string;
  };
  assessment: {
    id: string;
    status: string;
    completed_at: string;
    scores: {
      role_scores: Record<string, number>;
      stage_scores: Record<string, number>;
      derived: { change_capacity_score: number };
    } | null;
  } | null;
  payments: Array<{
    id: string;
    amount_minor: number;
    currency: string;
    status: string;
    created_at: string;
  }>;
  memberships: Array<{ teams: { id: string; name: string }; status: string }>;
}

export default function AdminUserDetail() {
  const { id } = useParams();
  const router = useRouter();
  const [user, setUser] = useState<UserDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    fetch(`/api/admin/users/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setUser(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  const updateUser = async (field: string, value: boolean | string) => {
    setUpdating(true);
    await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ [field]: value }),
    });
    // Refresh data
    const res = await fetch(`/api/admin/users/${id}`);
    const data = await res.json();
    setUser(data);
    setUpdating(false);
  };

  if (loading) {
    return (
      <AdminLayout>
        <div style={{ color: "white", textAlign: "center", padding: 48 }}>
          Loading user data...
        </div>
      </AdminLayout>
    );
  }

  if (!user) {
    return (
      <AdminLayout>
        <div style={{ color: "white", textAlign: "center", padding: 48 }}>
          User not found
        </div>
      </AdminLayout>
    );
  }

  const capacityScore =
    user.assessment?.scores?.derived?.change_capacity_score || null;

  return (
    <AdminLayout>
      <div>
        <button
          onClick={() => router.back()}
          style={{
            marginBottom: 24,
            background: "none",
            border: "none",
            color: "#6C3FC5",
            cursor: "pointer",
          }}
        >
          ← Back to Users
        </button>

        <div
          style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}
        >
          {/* Profile Card */}
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 20,
              }}
            >
              Profile
            </h2>
            <div style={{ marginBottom: 16 }}>
              <div
                style={{
                  fontSize: 12,
                  color: "rgba(255,255,255,0.5)",
                  marginBottom: 4,
                }}
              >
                Full Name
              </div>
              <div style={{ fontSize: 16, fontWeight: 500, color: "white" }}>
                {user.profile.full_name || "—"}
              </div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div
                style={{
                  fontSize: 12,
                  color: "rgba(255,255,255,0.5)",
                  marginBottom: 4,
                }}
              >
                Email
              </div>
              <div style={{ fontSize: 16, color: "white" }}>
                {user.profile.email}
              </div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div
                style={{
                  fontSize: 12,
                  color: "rgba(255,255,255,0.5)",
                  marginBottom: 4,
                }}
              >
                Joined
              </div>
              <div style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>
                {new Date(user.profile.created_at).toLocaleDateString()}
              </div>
            </div>
            <div style={{ display: "flex", gap: 12, marginTop: 20 }}>
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  cursor: "pointer",
                }}
              >
                <input
                  type="checkbox"
                  checked={user.profile.has_paid}
                  onChange={(e) => updateUser("has_paid", e.target.checked)}
                  disabled={updating}
                />
                <span style={{ color: "white" }}>Has Paid</span>
              </label>
            </div>
          </div>

          {/* Assessment Card */}
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 20,
              }}
            >
              Assessment
            </h2>
            {user.assessment ? (
              <>
                <div style={{ marginBottom: 16 }}>
                  <div
                    style={{
                      fontSize: 12,
                      color: "rgba(255,255,255,0.5)",
                      marginBottom: 4,
                    }}
                  >
                    Status
                  </div>
                  <span
                    style={{
                      display: "inline-block",
                      padding: "4px 10px",
                      borderRadius: 20,
                      fontSize: 12,
                      background:
                        user.assessment.status === "completed"
                          ? "rgba(16,185,129,0.15)"
                          : "rgba(244,200,66,0.15)",
                      color:
                        user.assessment.status === "completed"
                          ? "#10B981"
                          : "#F4C842",
                    }}
                  >
                    {user.assessment.status}
                  </span>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div
                    style={{
                      fontSize: 12,
                      color: "rgba(255,255,255,0.5)",
                      marginBottom: 4,
                    }}
                  >
                    Completed
                  </div>
                  <div style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>
                    {user.assessment.completed_at
                      ? new Date(
                          user.assessment.completed_at,
                        ).toLocaleDateString()
                      : "—"}
                  </div>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div
                    style={{
                      fontSize: 12,
                      color: "rgba(255,255,255,0.5)",
                      marginBottom: 4,
                    }}
                  >
                    Change Capacity Score
                  </div>
                  <div
                    style={{ fontSize: 24, fontWeight: 700, color: "#F4C842" }}
                  >
                    {capacityScore || "—"}/100
                  </div>
                </div>
                <div>
                  <div
                    style={{
                      fontSize: 12,
                      color: "rgba(255,255,255,0.5)",
                      marginBottom: 8,
                    }}
                  >
                    Role
                  </div>
                  <div style={{ fontSize: 14, color: "white" }}>
                    {user.profile.change_genius_role || "Not taken"} +{" "}
                    {user.profile.change_genius_role_2 || "—"}
                  </div>
                </div>
              </>
            ) : (
              <div
                style={{
                  color: "rgba(255,255,255,0.5)",
                  textAlign: "center",
                  padding: 32,
                }}
              >
                No assessment taken yet
              </div>
            )}
          </div>

          {/* Teams Card */}
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 20,
              }}
            >
              Teams
            </h2>
            {user.memberships.length > 0 ? (
              user.memberships.map((m, i) => (
                <div
                  key={i}
                  style={{
                    marginBottom: 12,
                    padding: 12,
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: 8,
                  }}
                >
                  <div style={{ fontWeight: 500, color: "white" }}>
                    {m.teams.name}
                  </div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>
                    Status: {m.status}
                  </div>
                </div>
              ))
            ) : (
              <div
                style={{
                  color: "rgba(255,255,255,0.5)",
                  textAlign: "center",
                  padding: 32,
                }}
              >
                No team memberships
              </div>
            )}
          </div>

          {/* Payments Card */}
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 20,
              }}
            >
              Payments
            </h2>
            {user.payments.length > 0 ? (
              user.payments.map((p, i) => (
                <div
                  key={i}
                  style={{
                    marginBottom: 12,
                    padding: 12,
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: 8,
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 500, color: "#F4C842" }}>
                      {p.currency === "NGN"
                        ? `₦${(p.amount_minor / 100).toLocaleString()}`
                        : `$${(p.amount_minor / 100).toLocaleString()}`}
                    </div>
                    <div
                      style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}
                    >
                      {new Date(p.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <span
                    style={{
                      padding: "2px 8px",
                      borderRadius: 12,
                      fontSize: 10,
                      background:
                        p.status === "completed"
                          ? "rgba(16,185,129,0.15)"
                          : "rgba(239,68,68,0.15)",
                      color: p.status === "completed" ? "#10B981" : "#EF4444",
                    }}
                  >
                    {p.status}
                  </span>
                </div>
              ))
            ) : (
              <div
                style={{
                  color: "rgba(255,255,255,0.5)",
                  textAlign: "center",
                  padding: 32,
                }}
              >
                No payments recorded
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
