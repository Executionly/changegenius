// app/admin/components/AdminLayout.tsx
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

interface AdminLayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { href: "/admin", label: "Overview", icon: "📊" },
  { href: "/admin/users", label: "Users", icon: "👥" },
  { href: "/admin/teams", label: "Teams", icon: "🏢" },
  { href: "/admin/payments", label: "Payments", icon: "💰" },
  { href: "/admin/admins", label: "Admins", icon: "🔐" },
  { href: "/admin/audit-logs", label: "Audit Logs", icon: "📜" },
  { href: "/admin/questions", label: "Questions", icon: "📋" },
];

// Get token from cookie
function getTokenFromCookie(): string | null {
  if (typeof document === "undefined") return null;
  const match = document.cookie.match(/admin_token=([^;]+)/);
  return match ? match[1] : null;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [admin, setAdmin] = useState<{
    fullName: string;
    email: string;
    role: string;
  } | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getTokenFromCookie();

    if (!token) {
      router.push("/admin/login");
      setLoading(false);
      return;
    }

    // Send token as Bearer header - this matches your backend's requireAdmin
    fetch("/api/admin/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then(async (res) => {
        if (res.status === 401 || res.status === 403) {
          router.push("/admin/login");
          return null;
        }
        return res.json();
      })
      .then((data) => {
        if (data && !data.error) {
          setAdmin(data);
        }
        setLoading(false);
      })
      .catch(() => {
        router.push("/admin/login");
        setLoading(false);
      });
  }, [router]);

  const handleLogout = async () => {
    const token = getTokenFromCookie();

    if (token) {
      await fetch("/api/admin/auth/logout", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

    // Clear cookie
    document.cookie =
      "admin_token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
    router.push("/admin/login");
  };

  if (loading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#080E1C",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ color: "white" }}>Loading...</div>
      </div>
    );
  }

  if (!admin) {
    return null;
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0D1628" }}>
      {/* Sidebar */}
      <aside
        style={{
          width: collapsed ? 72 : 260,
          background: "#080E1C",
          borderRight: "1px solid rgba(255,255,255,0.07)",
          transition: "width 0.2s",
          display: "flex",
          flexDirection: "column",
          position: "fixed",
          height: "100vh",
          overflow: "hidden",
          zIndex: 50,
        }}
      >
        <div
          style={{
            padding: "24px 20px",
            borderBottom: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          {!collapsed ? (
            <>
              <div style={{ fontSize: 20, fontWeight: 800, color: "#F4C842" }}>
                Change Genius
              </div>
              <div
                style={{
                  fontSize: 12,
                  color: "rgba(255,255,255,0.4)",
                  marginTop: 4,
                }}
              >
                Admin Console
              </div>
            </>
          ) : (
            <div
              style={{
                fontSize: 24,
                fontWeight: 800,
                color: "#F4C842",
                textAlign: "center",
              }}
            >
              CG
            </div>
          )}
        </div>

        <button
          onClick={() => setCollapsed(!collapsed)}
          style={{
            position: "absolute",
            right: -12,
            top: 80,
            width: 24,
            height: 24,
            borderRadius: 12,
            background: "#6C3FC5",
            border: "none",
            color: "white",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 60,
          }}
        >
          {collapsed ? "→" : "←"}
        </button>

        <nav style={{ flex: 1, padding: "20px 12px", overflowY: "auto" }}>
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 12px",
                  borderRadius: 8,
                  marginBottom: 4,
                  background: isActive ? "rgba(108,63,197,0.2)" : "transparent",
                  color: isActive ? "#F4C842" : "rgba(255,255,255,0.7)",
                  textDecoration: "none",
                  fontSize: 14,
                  fontWeight: 500,
                  transition: "all 0.15s",
                }}
              >
                <span style={{ fontSize: 18 }}>{item.icon}</span>
                {!collapsed && <span>{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        <div
          style={{
            padding: "20px",
            borderTop: "1px solid rgba(255,255,255,0.07)",
          }}
        >
          {!collapsed ? (
            <>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  marginBottom: 12,
                }}
              >
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    background: "#6C3FC5",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontWeight: 700,
                    color: "white",
                  }}
                >
                  {admin.fullName?.[0] || admin.email[0]}
                </div>
                <div>
                  <div
                    style={{ fontSize: 14, fontWeight: 600, color: "white" }}
                  >
                    {admin.fullName || "Admin"}
                  </div>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>
                    {admin.role}
                  </div>
                </div>
              </div>
              <button
                onClick={handleLogout}
                style={{
                  width: "100%",
                  padding: "8px",
                  background: "rgba(239,68,68,0.15)",
                  border: "1px solid rgba(239,68,68,0.3)",
                  borderRadius: 6,
                  color: "#EF4444",
                  fontSize: 13,
                  cursor: "pointer",
                }}
              >
                Logout
              </button>
            </>
          ) : (
            <div style={{ textAlign: "center" }}>
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  background: "#6C3FC5",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  margin: "0 auto",
                  fontWeight: 700,
                  color: "white",
                }}
              >
                {admin.fullName?.[0] || admin.email[0]}
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main content */}
      <main
        style={{
          marginLeft: collapsed ? 72 : 260,
          flex: 1,
          padding: "24px 32px",
          transition: "margin-left 0.2s",
        }}
      >
        {children}
      </main>
    </div>
  );
}
