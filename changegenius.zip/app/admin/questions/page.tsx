"use client";

import { useState, useEffect } from "react";
import AdminLayout from "../components/AdminLayout";

interface Question {
  id: string;
  text: string;
  role: string;
  stage: string;
  energy: string;
  reverse: boolean;
  order: number;
}

export default function AdminQuestions() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("/api/admin/super?type=questions")
      .then((res) => res.json())
      .then((data) => {
        setQuestions(data.questions || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredQuestions = questions.filter(
    (q) =>
      q.text.toLowerCase().includes(search.toLowerCase()) ||
      q.role.toLowerCase().includes(search.toLowerCase()) ||
      q.stage.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <AdminLayout>
      <div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 24,
          }}
        >
          <div>
            <h1
              style={{
                fontSize: 28,
                fontWeight: 700,
                color: "white",
                marginBottom: 4,
              }}
            >
              Question Bank
            </h1>
            <p style={{ color: "rgba(255,255,255,0.5)" }}>
              Review assessment questions ({questions.length} total)
            </p>
          </div>
          <input
            type="text"
            placeholder="Search questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: "8px 12px",
              width: 250,
              background: "#131F38",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 6,
              color: "white",
            }}
          />
        </div>

        {loading ? (
          <div
            style={{
              textAlign: "center",
              padding: 48,
              color: "rgba(255,255,255,0.5)",
            }}
          >
            Loading questions...
          </div>
        ) : (
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              overflow: "auto",
              border: "1px solid rgba(255,255,255,0.07)",
              maxHeight: "calc(100vh - 200px)",
            }}
          >
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead
                style={{
                  background: "#0D1628",
                  borderBottom: "1px solid rgba(255,255,255,0.07)",
                  position: "sticky",
                  top: 0,
                }}
              >
                <tr>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "left",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                      width: 60,
                    }}
                  >
                    #
                  </th>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "left",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                    }}
                  >
                    Question
                  </th>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "left",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                      width: 100,
                    }}
                  >
                    Role
                  </th>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "left",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                      width: 100,
                    }}
                  >
                    Stage
                  </th>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "left",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                      width: 80,
                    }}
                  >
                    Energy
                  </th>
                  <th
                    style={{
                      padding: "12px 16px",
                      textAlign: "center",
                      color: "rgba(255,255,255,0.6)",
                      fontSize: 12,
                      width: 70,
                    }}
                  >
                    Reverse
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredQuestions.map((q) => (
                  <tr
                    key={q.id}
                    style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
                  >
                    <td
                      style={{
                        padding: "12px 16px",
                        color: "rgba(255,255,255,0.4)",
                        fontSize: 12,
                      }}
                    >
                      {q.order}
                    </td>
                    <td
                      style={{
                        padding: "12px 16px",
                        color: "rgba(255,255,255,0.8)",
                        fontSize: 13,
                      }}
                    >
                      {q.text}
                    </td>
                    <td
                      style={{
                        padding: "12px 16px",
                        color: "#F4C842",
                        fontSize: 12,
                      }}
                    >
                      {q.role}
                    </td>
                    <td
                      style={{
                        padding: "12px 16px",
                        color: "#6C3FC5",
                        fontSize: 12,
                      }}
                    >
                      {q.stage}
                    </td>
                    <td
                      style={{
                        padding: "12px 16px",
                        color: "#10B981",
                        fontSize: 12,
                      }}
                    >
                      {q.energy}
                    </td>
                    <td
                      style={{
                        padding: "12px 16px",
                        textAlign: "center",
                        color: q.reverse ? "#EF4444" : "rgba(255,255,255,0.4)",
                        fontSize: 12,
                      }}
                    >
                      {q.reverse ? "Yes" : "No"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
