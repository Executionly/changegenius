"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import AdminLayout from "../../components/AdminLayout";

interface TeamDetail {
  team: {
    id: string;
    name: string;
    organization: string | null;
    created_at: string;
    owner: { id: string; email: string; full_name: string | null };
  };
  members: Array<{
    id: string;
    status: string;
    joined_at: string;
    profile: {
      id: string;
      email: string;
      full_name: string | null;
      change_genius_role: string | null;
      primary_energy: string | null;
    };
  }>;
  report: {
    report_json: any;
    risk_score: number;
    member_count: number;
  } | null;
  pulseWeeks: Array<{
    week: number;
    dialogue: number;
    alignment: number;
    execution: number;
  }>;
}

export default function AdminTeamDetail() {
  const { id } = useParams();
  const router = useRouter();
  const [team, setTeam] = useState<TeamDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/admin/teams/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setTeam(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  const removeMember = async (userId: string) => {
    if (!confirm("Remove this member from the team?")) return;
    await fetch(`/api/admin/teams/${id}/members/${userId}`, {
      method: "DELETE",
    });
    // Refresh
    const res = await fetch(`/api/admin/teams/${id}`);
    const data = await res.json();
    setTeam(data);
  };

  const deleteTeam = async () => {
    if (
      !confirm(
        `Delete team "${team?.team.name}"? This action cannot be undone.`,
      )
    )
      return;
    await fetch(`/api/admin/teams/${id}`, { method: "DELETE" });
    router.push("/admin/teams");
  };

  if (loading) {
    return (
      <AdminLayout>
        <div style={{ color: "white", textAlign: "center", padding: 48 }}>
          Loading team data...
        </div>
      </AdminLayout>
    );
  }

  if (!team) {
    return (
      <AdminLayout>
        <div style={{ color: "white", textAlign: "center", padding: 48 }}>
          Team not found
        </div>
      </AdminLayout>
    );
  }

  const riskLevel = team.report?.risk_score || 0;

  return (
    <AdminLayout>
      <div>
        <button
          onClick={() => router.back()}
          style={{
            marginBottom: 24,
            background: "none",
            border: "none",
            color: "#6C3FC5",
            cursor: "pointer",
          }}
        >
          ← Back to Teams
        </button>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "start",
            marginBottom: 24,
          }}
        >
          <div>
            <h1
              style={{
                fontSize: 28,
                fontWeight: 700,
                color: "white",
                marginBottom: 4,
              }}
            >
              {team.team.name}
            </h1>
            <p style={{ color: "rgba(255,255,255,0.5)" }}>
              {team.team.organization || "No organization"} • Created{" "}
              {new Date(team.team.created_at).toLocaleDateString()}
            </p>
          </div>
          <button
            onClick={deleteTeam}
            style={{
              padding: "8px 16px",
              background: "rgba(239,68,68,0.15)",
              border: "1px solid rgba(239,68,68,0.3)",
              borderRadius: 6,
              color: "#EF4444",
              cursor: "pointer",
            }}
          >
            Delete Team
          </button>
        </div>

        {/* Risk Score Card */}
        {team.report && (
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
              marginBottom: 24,
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 16,
              }}
            >
              Team Risk Assessment
            </h2>
            <div style={{ display: "flex", gap: 32, alignItems: "center" }}>
              <div>
                <div
                  style={{
                    fontSize: 48,
                    fontWeight: 700,
                    color:
                      riskLevel > 70
                        ? "#EF4444"
                        : riskLevel > 40
                          ? "#F4C842"
                          : "#10B981",
                  }}
                >
                  {riskLevel}
                </div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                  Risk Score
                </div>
              </div>
              <div
                style={{
                  width: 1,
                  height: 40,
                  background: "rgba(255,255,255,0.1)",
                }}
              />
              <div>
                <div style={{ fontSize: 24, fontWeight: 600, color: "white" }}>
                  {team.report.member_count}
                </div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.5)" }}>
                  Total Members
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Members Table */}
        <div
          style={{
            background: "#131F38",
            borderRadius: 12,
            overflow: "hidden",
            border: "1px solid rgba(255,255,255,0.07)",
            marginBottom: 24,
          }}
        >
          <div
            style={{
              padding: "20px 24px",
              borderBottom: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2 style={{ fontSize: 18, fontWeight: 600, color: "white" }}>
              Members ({team.members.length})
            </h2>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead
              style={{
                background: "#0D1628",
                borderBottom: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <tr>
                <th
                  style={{
                    padding: "12px 16px",
                    textAlign: "left",
                    color: "rgba(255,255,255,0.6)",
                    fontSize: 13,
                  }}
                >
                  Member
                </th>
                <th
                  style={{
                    padding: "12px 16px",
                    textAlign: "left",
                    color: "rgba(255,255,255,0.6)",
                    fontSize: 13,
                  }}
                >
                  Role
                </th>
                <th
                  style={{
                    padding: "12px 16px",
                    textAlign: "left",
                    color: "rgba(255,255,255,0.6)",
                    fontSize: 13,
                  }}
                >
                  Energy
                </th>
                <th
                  style={{
                    padding: "12px 16px",
                    textAlign: "center",
                    color: "rgba(255,255,255,0.6)",
                    fontSize: 13,
                  }}
                >
                  Status
                </th>
                <th
                  style={{
                    padding: "12px 16px",
                    textAlign: "center",
                    color: "rgba(255,255,255,0.6)",
                    fontSize: 13,
                  }}
                ></th>
              </tr>
            </thead>
            <tbody>
              {team.members.map((member) => (
                <tr
                  key={member.id}
                  style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
                >
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ fontWeight: 500, color: "white" }}>
                      {member.profile.full_name || "—"}
                    </div>
                    <div
                      style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}
                    >
                      {member.profile.email}
                    </div>
                  </td>
                  <td
                    style={{
                      padding: "12px 16px",
                      color: "rgba(255,255,255,0.7)",
                    }}
                  >
                    {member.profile.change_genius_role || "—"}
                  </td>
                  <td
                    style={{
                      padding: "12px 16px",
                      color: "rgba(255,255,255,0.7)",
                    }}
                  >
                    {member.profile.primary_energy || "—"}
                  </td>
                  <td style={{ padding: "12px 16px", textAlign: "center" }}>
                    <span
                      style={{
                        display: "inline-block",
                        padding: "2px 8px",
                        borderRadius: 12,
                        fontSize: 10,
                        background:
                          member.status === "completed"
                            ? "rgba(16,185,129,0.15)"
                            : "rgba(244,200,66,0.15)",
                        color:
                          member.status === "completed" ? "#10B981" : "#F4C842",
                      }}
                    >
                      {member.status}
                    </span>
                  </td>
                  <td style={{ padding: "12px 16px", textAlign: "center" }}>
                    <button
                      onClick={() => removeMember(member.profile.id)}
                      style={{
                        background: "none",
                        border: "none",
                        color: "#EF4444",
                        cursor: "pointer",
                        fontSize: 12,
                      }}
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pulse Chart Section */}
        {team.pulseWeeks.length > 0 && (
          <div
            style={{
              background: "#131F38",
              borderRadius: 12,
              padding: 24,
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            <h2
              style={{
                fontSize: 18,
                fontWeight: 600,
                color: "white",
                marginBottom: 16,
              }}
            >
              Weekly Pulse
            </h2>
            <div style={{ display: "flex", gap: 32, flexWrap: "wrap" }}>
              {team.pulseWeeks.slice(-8).map((week) => (
                <div
                  key={week.week}
                  style={{ textAlign: "center", minWidth: 60 }}
                >
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>
                    Week {week.week}
                  </div>
                  <div style={{ marginTop: 8 }}>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: 4,
                      }}
                    >
                      <div>
                        <span style={{ color: "#10B981" }}>●</span>{" "}
                        <span style={{ fontSize: 12, color: "white" }}>
                          {week.dialogue}
                        </span>
                      </div>
                      <div>
                        <span style={{ color: "#F4C842" }}>●</span>{" "}
                        <span style={{ fontSize: 12, color: "white" }}>
                          {week.alignment}
                        </span>
                      </div>
                      <div>
                        <span style={{ color: "#6C3FC5" }}>●</span>{" "}
                        <span style={{ fontSize: 12, color: "white" }}>
                          {week.execution}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
