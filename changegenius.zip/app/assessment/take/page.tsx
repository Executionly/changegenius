"use client";
import { useState, useEffect, useCallback, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { ORDERED_QUESTIONS, TOTAL_QUESTIONS } from "@/lib/assessment/questions";
import { createBrowserClient } from "@supabase/ssr";
type SaveStatus = "idle" | "saving" | "saved" | "error";

const LABELS = [
  "Strongly Disagree",
  "Disagree",
  "Neutral",
  "Agree",
  "Strongly Agree",
];

interface ITeamReport {
  id: string,
  blob: any,
  base64: any,
  teamName: string;
  teamOEmail: string;
  teamOName: string;
  totalMembers: string;
}

function AssessmentTakePageContent() {
  const { isAuthenticated, profile, loading: authLoading, user, session } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const isRetake = searchParams.get("retake") === "true";
  const teamId = searchParams.get("teamId")

  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const [loadingState, setLoadingState] = useState<
    "init" | "ready" | "submitting" | "done"
  >("init");
  const [error, setError] = useState("");
  const [emailLoading, setEmailLoading] = useState(false)
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  const question = ORDERED_QUESTIONS[currentIndex];
  const progress = Math.round((currentIndex / TOTAL_QUESTIONS) * 100);
  const answered = Object.keys(answers).length;
  const currentAnswer = question ? (answers[question.id] ?? null) : null;
  const isLast = currentIndex === TOTAL_QUESTIONS - 1;
  const allAnswered = answered === TOTAL_QUESTIONS;

  // Auth + payment guard
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/auth?returnUrl=/assessment/take");
      return;
    }
    if (profile && !profile.has_paid && !teamId) {
      router.push("/payment?plan=individual");
      return;
    }
  }, [authLoading, user, profile, router]);

  // Start or resume assessment
  useEffect(() => {
    if (authLoading || !isAuthenticated || (!profile?.has_paid && !teamId)) return;
    async function init() {
      try {
        const url = isRetake
          ? "/api/assessment/start?fresh=true"
          : "/api/assessment/start";
        const res = await fetch(url, { method: "POST", body: JSON.stringify({ teamId }) });
        if (!res.ok) {
          const data = await res.json();
          if (res.status === 403 && data.paymentRequired) {
            router.push("/payment?plan=individual");
            return;
          }
          throw new Error("Failed to start");
        }
        const data = (await res.json()) as {
          assessmentId: string;
          lastQuestionIndex: number;
          answeredResponses: Record<string, number>;
        };
        setAssessmentId(data.assessmentId);
        setAnswers(data.answeredResponses);
        setCurrentIndex(data.lastQuestionIndex);
        setLoadingState("ready");
        if (isRetake) {
          router.replace("/assessment/take", undefined);
        }
      } catch {
        setError("Could not start assessment. Please refresh and try again.");
        setLoadingState("ready");
      }
    }
    void init();
  }, [authLoading, isAuthenticated, profile, router, isRetake, teamId]);

  // Save single answer
  const saveAnswer = useCallback(
    async (qId: string, value: number, qIndex: number) => {
      if (!assessmentId) return;
      setSaveStatus("saving");
      try {
        const res = await fetch("/api/assessment/answer", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            assessmentId,
            questionId: qId,
            value,
            questionIndex: qIndex,
            teamId
          }),
        });
        setSaveStatus(res.ok ? "saved" : "error");
        setTimeout(() => setSaveStatus("idle"), 1200);
      } catch {
        setSaveStatus("error");
      }
    },
    [assessmentId, teamId],
  );

  function selectAnswer(value: number) {
    if (!question) return;
    const qId = question.id;
    setAnswers((prev) => ({ ...prev, [qId]: value }));
    void saveAnswer(qId, value, currentIndex);
  }

  function goNext() {
    if (currentAnswer == null) return;
    if (currentIndex < TOTAL_QUESTIONS - 1) {
      setCurrentIndex((i) => i + 1);
      setError("");
    }
  }

  function goBack() {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      setError("");
    }
  }

  async function handleSubmit() {
    if (!assessmentId) return;
    if (!allAnswered) {
      const firstUnanswered = ORDERED_QUESTIONS.findIndex(
        (q) => !(q.id in answers),
      );
      if (firstUnanswered >= 0) setCurrentIndex(firstUnanswered);
      setError(
        `Please answer all questions. ${TOTAL_QUESTIONS - answered} remaining.`,
      );
      return;
    }
    setLoadingState("submitting");
    setError("");
    try {
      const res = await fetch("/api/assessment/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ assessmentId }),
      });
      if (!res.ok) {
        throw new Error("Submission failed, try again later");
      }
      const data = await res.json()
      const {team} = data
      let teamData;
      try {
        if(team && team?.html){
          const pdf = await generateBlob(team?.html)
          teamData = {
            id: team?.teamId,
            blob:pdf?.blob,
            base64:pdf?.base64,
            teamName: team?.teamName,
            teamOName: team?.teamOName,
            teamOEmail: team?.teamOEmail,
            totalMembers: team?.totalMembers,
          }
        }
        await handleEmailPDF(teamData)
      }catch(err) {
        console.error("Failed to email PDF:", err)
      }finally{
        setLoadingState("done");
        window.location.href = "/results";
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Submission failed. Please try again.",
      );
      setLoadingState("ready");
    }
  }

  const generatePDFBlob = async (): Promise<{ blob: Blob; base64: string } | null> => {
    const res = await fetch("/api/pdf/individual", { credentials: "include" });
    if (!res.ok) return null;

    const contentType = res.headers.get("content-type") ?? "";
    if (!contentType.includes("text/html")) return null;

    const html = await res.text();
    return await generateBlob(html)
  };

  const generateBlob = async (html: any): Promise<{ blob: Blob; base64: string } | null> => {
    const { default: html2canvas } = await import("html2canvas");
    const { default: jsPDF } = await import("jspdf");

    const iframe = document.createElement("iframe");
    iframe.style.cssText = "position:fixed;top:0;left:0;width:794px;height:1123px;opacity:0;pointer-events:none;border:none;";
    document.body.appendChild(iframe);

    const iframeDoc = iframe.contentDocument!;
    iframeDoc.open();
    iframeDoc.write(html);
    iframeDoc.close();

    await new Promise(resolve => setTimeout(resolve, 2500));

    const pageEls = iframeDoc.querySelectorAll<HTMLElement>(".page");
    const pdf = new jsPDF({ unit: "mm", format: "a4", orientation: "portrait" });
    const pdfWidthMm = 210;
    const pdfHeightMm = 297;

    for (let i = 0; i < pageEls.length; i++) {
      const el = pageEls[i];

      const canvas = await html2canvas(el, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        width: 794,
        height: 1123,
        windowWidth: 794,
        windowHeight: 1123,
        backgroundColor: "#ffffff",
        logging: false,
        imageTimeout: 0,
      });

      const imgData = canvas.toDataURL("image/jpeg", 0.6);

      if (i > 0) pdf.addPage();

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidthMm, pdfHeightMm);
    }

    document.body.removeChild(iframe);

    const blob = pdf.output("blob");
    const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    return { blob, base64 };
  }

  const handleEmailPDF = async (team?: ITeamReport) => {
    setEmailLoading(true)
    try {
      const result = await generatePDFBlob();
      if (!result) throw new Error("Failed to generate PDF");
  
      const filePath = `${session?.user.id}/report-${Date.now()}.pdf`;
      let teamFilePath = null

      const { error: uploadError } = await supabase.storage
        .from("reports")
        .upload(filePath, result.blob, {
          contentType: "application/pdf",
          upsert: true,
        });
  
      if (uploadError) throw new Error(`Upload failed: ${uploadError.message}`);
      
      if(team?.blob && team.id){
        teamFilePath = `${team?.id}/team-report-${Date.now()}.pdf`;

        const { error: uploadTError } = await supabase.storage
        .from("reports")
        .upload(teamFilePath, team.blob, {
          contentType: "application/pdf",
          upsert: true,
        });
  
        if (uploadTError) throw new Error(`Upload failed: ${uploadTError.message}`);
      }
  
      const res = await fetch("/api/pdf/email", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          filePath, 
          teamFilePath,
          teamId: team?.id,
          teamOEmail: team?.teamOEmail,
          teamOName: team?.teamOName,
          totalMembers: team?.totalMembers,
          teamName: team?.teamName,
        }),
      });
  
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error ?? "Failed to send email");
      }
  
      await supabase.storage.from("reports").remove([filePath]);
      if(teamFilePath){
        await supabase.storage.from("reports").remove([teamFilePath]);
      }
    } catch (err) {
      console.error("Email PDF failed:", err);
      alert("Failed to send email. Please try downloading instead.");
    } finally {
      setEmailLoading(false)
    }
  };

  if (authLoading || loadingState === "init")
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "var(--sage)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div
            style={{ fontSize: 13, color: "var(--text-3)", marginBottom: 10 }}
          >
            Loading your assessment…
          </div>
          <div
            style={{
              width: 200,
              height: 3,
              background: "var(--border)",
              borderRadius: 2,
              overflow: "hidden",
              margin: "0 auto",
            }}
          >
            <div
              style={{
                height: "100%",
                background: "var(--blue)",
                width: "40%",
                animation: "loadbar 1.2s ease infinite",
                borderRadius: 2,
              }}
            />
          </div>
        </div>
        <style>{`@keyframes loadbar{0%{transform:translateX(-100%)}100%{transform:translateX(400%)}}`}</style>
      </div>
    );

  if (loadingState === "submitting")
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "var(--sage)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>⚙️</div>
          <div
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: "var(--navy)",
              marginBottom: 8,
            }}
          >
            Calculating your results…
          </div>
          <div style={{ fontSize: 13, color: "var(--text-3)" }}>
            This takes just a moment.
          </div>
          {emailLoading && (
            <>
              <div className="pdf-spinner">
                <svg
                  width="64"
                  height="64"
                  viewBox="0 0 64 64"
                  style={{ animation: "spin 1.2s linear infinite" }}
                >
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke="rgba(255,255,255,0.08)"
                    strokeWidth="4"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke="#12A74C"
                    strokeWidth="4"
                    strokeDasharray="40 124"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="pdf-icon">✉️</div>
              </div>
              <div className="pdf-title">Sending your report</div>
              <div className="pdf-desc">
                Compiling your results and sending them to your email.
                <br />
                This usually takes 20–30 seconds.
              </div>
              <div className="pdf-dots">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="pdf-dot"
                    style={{ animationDelay: `${i * 0.2}s` }}
                  />
                ))}
              </div>
            </>
      )}
        </div>
      </div>
    );

  if (!question) return null;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "var(--sage)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div style={{ background: "var(--blue)", flexShrink: 0 }}>
        <div
          style={{
            maxWidth: 800,
            margin: "0 auto",
            padding: "0 24px",
            height: 52,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <span
            style={{
              fontSize: 15,
              fontWeight: 800,
              color: "blue",
              letterSpacing: "-0.3px",
            }}
          >
            ChangeGenius™
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {saveStatus === "saving" && (
              <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
                Saving…
              </span>
            )}
            {saveStatus === "saved" && (
              <span style={{ fontSize: 12, color: "#86efac" }}>✓ Saved</span>
            )}
            {saveStatus === "error" && (
              <span style={{ fontSize: 12, color: "#fca5a5" }}>
                ⚠ Save failed
              </span>
            )}
            <span style={{ fontSize: 12, color: "rgba(255,255,255,.45)" }}>
              {answered}/{TOTAL_QUESTIONS} answered
            </span>
          </div>
        </div>
      </div>

      <div
        style={{ height: 4, background: "rgba(10,37,64,.08)", flexShrink: 0 }}
      >
        <div
          style={{
            height: "100%",
            background: "var(--blue)",
            width: `${progress}%`,
            transition: "width .3s ease",
            borderRadius: "0 2px 2px 0",
          }}
        />
      </div>

      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "32px 20px",
        }}
      >
        <div style={{ width: "100%", maxWidth: 640 }}>
          <div
            style={{
              background: "white",
              borderRadius: "var(--radius)",
              padding: "40px 44px",
              boxShadow: "0 2px 16px rgba(10,37,64,.07)",
              marginBottom: 16,
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                marginBottom: 20,
              }}
            >
              {/* role and stage labels removed to avoid bias during assessment */}
            </div>
            <div
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: "var(--text-4)",
                marginBottom: 8,
              }}
            >
              Question {currentIndex + 1} of {TOTAL_QUESTIONS}
            </div>
            <h2
              style={{
                fontSize: "clamp(17px,2.5vw,22px)",
                fontWeight: 700,
                color: "var(--navy)",
                lineHeight: 1.5,
                marginBottom: 32,
                letterSpacing: "-0.2px",
              }}
            >
              {question.text}
            </h2>
            <fieldset style={{ border: "none", padding: 0, margin: 0 }}>
              <legend
                style={{
                  fontSize: 12,
                  fontWeight: 600,
                  color: "var(--text-3)",
                  marginBottom: 14,
                }}
              >
                Select one answer:
              </legend>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[1, 2, 3, 4, 5].map((val) => {
                  const selected = currentAnswer === val;
                  return (
                    <label
                      key={val}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 14,
                        padding: "13px 18px",
                        border: `2px solid ${selected ? "var(--blue)" : "var(--border)"}`,
                        borderRadius: 10,
                        background: selected ? "var(--blue-light)" : "white",
                        cursor: "pointer",
                        transition: "all .15s",
                      }}
                    >
                      <div
                        style={{
                          width: 20,
                          height: 20,
                          borderRadius: "50%",
                          flexShrink: 0,
                          border: `2px solid ${selected ? "var(--blue)" : "var(--border)"}`,
                          background: selected ? "var(--blue)" : "white",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        {selected && (
                          <div
                            style={{
                              width: 8,
                              height: 8,
                              borderRadius: "50%",
                              background: "white",
                            }}
                          />
                        )}
                      </div>
                      <input
                        type="radio"
                        name={`question-${currentIndex}`}
                        value={val}
                        checked={selected}
                        onChange={() => selectAnswer(val)}
                        style={{
                          position: "absolute",
                          opacity: 0,
                          width: 0,
                          height: 0,
                        }}
                      />
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          flex: 1,
                        }}
                      >
                        <span
                          style={{
                            fontSize: 13,
                            fontWeight: 700,
                            color: selected ? "var(--blue)" : "var(--text-4)",
                            minWidth: 16,
                          }}
                        >
                          {val}
                        </span>
                        <span
                          style={{
                            fontSize: 14,
                            fontWeight: selected ? 600 : 400,
                            color: selected ? "var(--navy)" : "var(--text-2)",
                          }}
                        >
                          {LABELS[val - 1]}
                        </span>
                      </div>
                      {selected && (
                        <span
                          style={{
                            fontSize: 16,
                            color: "var(--blue)",
                            marginLeft: "auto",
                          }}
                        >
                          ✓
                        </span>
                      )}
                    </label>
                  );
                })}
              </div>
            </fieldset>
          </div>

          {error && (
            <div
              style={{
                background: "#fef2f2",
                border: "1px solid #fecaca",
                borderRadius: 10,
                padding: "10px 16px",
                fontSize: 13,
                color: "#dc2626",
                marginBottom: 12,
              }}
            >
              {error}
            </div>
          )}

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <button
              onClick={goBack}
              disabled={currentIndex === 0}
              style={{
                padding: "11px 22px",
                borderRadius: "100px",
                border: "1.5px solid var(--border)",
                background: "white",
                fontSize: 14,
                fontWeight: 600,
                color: currentIndex === 0 ? "var(--text-4)" : "var(--text-1)",
                cursor: currentIndex === 0 ? "not-allowed" : "pointer",
                opacity: currentIndex === 0 ? 0.5 : 1,
                fontFamily: "Inter,sans-serif",
              }}
            >
              ← Back
            </button>

            <div
              style={{
                display: "flex",
                gap: 5,
                alignItems: "center",
                flex: 1,
                justifyContent: "center",
              }}
            >
              {Array.from({ length: 9 }, (_, i) => {
                const offset = i - 4;
                const qi = currentIndex + offset;
                if (qi < 0 || qi >= TOTAL_QUESTIONS)
                  return <div key={i} style={{ width: 6, height: 6 }} />;
                const q = ORDERED_QUESTIONS[qi];
                const isAnswered = q.id in answers;
                const isCurrent = qi === currentIndex;
                return (
                  <button
                    key={i}
                    onClick={() => setCurrentIndex(qi)}
                    title={`Question ${qi + 1}`}
                    style={{
                      width: isCurrent ? 20 : 8,
                      height: 8,
                      borderRadius: 4,
                      border: "none",
                      cursor: "pointer",
                      padding: 0,
                      background: isCurrent
                        ? "var(--blue)"
                        : isAnswered
                          ? "rgba(26,107,250,.4)"
                          : "var(--border)",
                    }}
                  />
                );
              })}
            </div>

            {isLast ? (
              <button
                onClick={handleSubmit}
                disabled={!allAnswered}
                style={{
                  padding: "11px 28px",
                  borderRadius: "100px",
                  border: "none",
                  background: allAnswered ? "var(--blue)" : "var(--border)",
                  color: allAnswered ? "white" : "var(--text-4)",
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: allAnswered ? "pointer" : "not-allowed",
                  fontFamily: "Inter,sans-serif",
                }}
              >
                {allAnswered
                  ? "Submit & See Results →"
                  : `${TOTAL_QUESTIONS - answered} remaining`}
              </button>
            ) : (
              <button
                onClick={goNext}
                disabled={currentAnswer === null}
                style={{
                  padding: "11px 28px",
                  borderRadius: "100px",
                  border: "none",
                  background:
                    currentAnswer === null ? "var(--border)" : "var(--blue)",
                  color: currentAnswer === null ? "var(--text-4)" : "white",
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: currentAnswer != null ? "pointer" : "not-allowed",
                  fontFamily: "Inter,sans-serif",
                }}
              >
                Next →
              </button>
            )}
          </div>

          {currentAnswer == null && (
            <p
              style={{
                textAlign: "center",
                fontSize: 12,
                color: "var(--text-4)",
                marginTop: 12,
              }}
            >
              Select an answer above to continue
            </p>
          )}

          {answered < TOTAL_QUESTIONS && answered > 0 && (
            <div style={{ textAlign: "center", marginTop: 8 }}>
              <button
                onClick={() => {
                  const first = ORDERED_QUESTIONS.findIndex(
                    (q) => !(q.id in answers),
                  );
                  if (first >= 0) setCurrentIndex(first);
                }}
                style={{
                  fontSize: 12,
                  color: "var(--text-4)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  fontFamily: "Inter,sans-serif",
                  textDecoration: "underline",
                }}
              >
                Jump to first unanswered ({TOTAL_QUESTIONS - answered} left)
              </button>
            </div>
          )}
        </div>
      </div>

      {emailLoading && (
        <div className="pdf-overlay">
          <div className="pdf-modal">
            <div className="pdf-spinner">
              <svg
                width="64"
                height="64"
                viewBox="0 0 64 64"
                style={{ animation: "spin 1.2s linear infinite" }}
              >
                <circle
                  cx="32"
                  cy="32"
                  r="26"
                  fill="none"
                  stroke="rgba(255,255,255,0.08)"
                  strokeWidth="4"
                />
                <circle
                  cx="32"
                  cy="32"
                  r="26"
                  fill="none"
                  stroke="#12A74C"
                  strokeWidth="4"
                  strokeDasharray="40 124"
                  strokeLinecap="round"
                />
              </svg>
              <div className="pdf-icon">✉️</div>
            </div>
            <div className="pdf-title">Sending your report</div>
            <div className="pdf-desc">
              Compiling your results and sending them to your email.
              <br />
              This usually takes 20–30 seconds.
            </div>
            <div className="pdf-dots">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="pdf-dot"
                  style={{ animationDelay: `${i * 0.2}s` }}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AssessmentTakePage() {
  return (
    <Suspense
      fallback={
        <div
          style={{
            minHeight: "100vh",
            background: "var(--sage)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Loading...
        </div>
      }
    >
      <AssessmentTakePageContent />
    </Suspense>
  );
}
